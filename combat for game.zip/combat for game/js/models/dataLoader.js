// js/models/dataLoader.js
// Handles all static game data (spells/concepts, enemies) and dynamic data scaling.

/**
 * DataLoader Class: Provides static access to game data and scaling logic.
 * It is responsible for asynchronously loading external JSON data files.
 */
export class DataLoader {
    static _concepts = null;
    static _enemies = null;

    /**
     * Asynchronously fetches all necessary game data from external JSON files.
     * This must be called and awaited before starting the game.
     */
    static async loadData() {
        try {
            // FIX: Use the correct filename for Java concepts.
            const conceptsResponse = await fetch('/data/java_concepts.json');
            const enemiesResponse = await fetch('/data/enemies.json');

            DataLoader._concepts = await conceptsResponse.json();
            DataLoader._enemies = await enemiesResponse.json();

            console.log("Game data loaded successfully.");
        } catch (error) {
            console.error("Error loading game data:", error);
            // Fallback or error handling can be added here
        }
    }

    // Synchronous getter methods used by other modules after data is loaded
    static getConceptData() {
        if (!DataLoader._concepts) throw new Error("Concept data not loaded. Call loadData() first.");
        return DataLoader._concepts;
    }

    // Synchronous getter methods used by other modules after data is loaded
    static getEnemyData() {
        if (!DataLoader._enemies) throw new Error("Enemy data not loaded. Call loadData() first.");
        return DataLoader._enemies;
    }

    /**
     * Generates enemy stats scaled to the player's current level.
     * @param {string} enemyId - The ID of the enemy to scale.
     * @param {number} playerLevel - The player's current level.
     * @returns {object} The scaled enemy object.
     */
    static getScaledEnemy(enemyId, playerLevel) {
        // Use the loaded data cache
        const enemyBase = DataLoader.getEnemyData().find(e => e.id === enemyId);
        if (!enemyBase) return null;

        const level = Math.min(Math.max(playerLevel, enemyBase.level_min), enemyBase.level_max);
        const scalingFactor = enemyBase.scaling_factor;
        
        // Apply scaling formula to base stats (rest of your scaling logic)
        const newStats = {
            hp: Math.round(enemyBase.base_stats.hp + (level * scalingFactor)),
            damage: Math.round(enemyBase.base_stats.damage + (level * (scalingFactor / 2))),
            defense: Math.round(enemyBase.base_stats.defense + (level * (scalingFactor / 4))),
            ram_pool: Math.round(enemyBase.base_stats.ram_pool + (level * (scalingFactor * 0.8))),
        };

        return {
            ...enemyBase,
            level: level,
            hp: newStats.hp,
            maxHp: newStats.hp,
            // ... (rest of the enemy properties) ...
            currentHp: newStats.hp,
            currentRamPool: newStats.ram_pool, 
            activeBuffs: { defenseBonus: 0, turnsRemaining: 0 },
            baseDefense: newStats.defense,
        };
    }
}