// js/main.js
// This file is the entry point for the application. It handles asynchronous data loading
// and initializes the Game class.

import { Game } from './game.js';
import { DataLoader } from './models/dataLoader.js'; // Import DataLoader

// Global game state object
window.gameState = {
    player: {
        hp: 100,
        maxHp: 100,
        ram: 50,
        maxRam: 50,
        level: 10,
    },
    enemy: null, 
    editor: null,
};

/**
 * The main async function to load data and start the game.
 */
async function initializeGame() {
    console.log("Loading game data...");
    
    // CRITICAL: Wait for data to load from JSON files before proceeding
    await DataLoader.loadData();

    // Data is loaded, now safely initialize the game
    window.game = new Game(window.gameState);
    console.log("Game initialized.");
}

// Monaco Loader setup needs to be accessible globally
// This must run before the window load event to ensure 'require' is configured when 'setupEditor' runs.
require.config({ paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.46.0/min/vs' }});


// Start the initialization process when the window loads.
window.addEventListener('load', () => {
    initializeGame();
});