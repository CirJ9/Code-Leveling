// js/ui/uiManager.js
// Dedicated to handling all interactions with the Document Object Model (DOM).

/**
 * UIManager Class: Handles all display and DOM updates.
 */
export class UIManager {
    constructor() {
        this.logElement = document.getElementById('combat-log');
        this.modalElement = document.getElementById('modal-panel');
        this.defenseBonusDisplay = document.getElementById('enemy-defense-bonus');
    }

    // Full updateStats logic from the original file
    updateStats(player, enemy) {
        document.getElementById('player-hp').textContent = player.hp;
        document.getElementById('player-ram').textContent = player.ram;
        // ... (update all other stats) ...
        
        document.getElementById('enemy-hp').textContent = `${enemy.currentHp} / ${enemy.maxHp}`;
        
        // ... (display defense buff status) ...
    }

    // Full updateRamCostDisplay logic from the original file
    updateRamCostDisplay(cost, maxRam, hasSyntaxError) {
        const display = document.getElementById('ram-cost-display');
        display.textContent = cost;
        display.className = `text-xl ${cost > maxRam ? 'text-red-500' : (hasSyntaxError ? 'text-yellow-500' : 'text-white')}`;
    }

    // Full log logic from the original file
    log(message, color = 'white') {
        const entry = document.createElement('p');
        entry.textContent = `> ${message}`;
        entry.style.color = color;
        this.logElement.appendChild(entry);
        this.logElement.scrollTop = this.logElement.scrollHeight;
    }

    // Full modal logic from the original file
    showModal(title, text) {
        document.getElementById('modal-title').textContent = title;
        document.getElementById('modal-text').textContent = text;
        this.modalElement.style.display = 'flex'; 
    }

    // Full hideModal logic from the original file
    hideModal() {
        this.modalElement.style.display = 'none';
    }
}