// js/game.js
// Contains the main Game class which manages turns, state transitions, and high-level logic.

import { UIManager } from './ui/uiManager.js';
import { CodeAnalyzer } from './logic/codeAnalyzer.js';
import { DataLoader } from './models/dataLoader.js';

/**
 * Game Class: The core orchestrator of the combat loop.
 */
export class Game {
    constructor(initialState) {
        this.gameState = initialState;
        this.ui = new UIManager();
        // Concept data is guaranteed to be loaded here thanks to async loading in main.js
        this.analyzer = new CodeAnalyzer(DataLoader.getConceptData());
        this.isPlayerTurn = true;
        
        this.setupEditor();
        this.startEncounter();
        this.setupEventListeners();
    }
    
    // Setup and Event Listeners logic (moved from the original single-file script)
    setupEventListeners() {
        document.getElementById('run-code-btn').addEventListener('click', () => this.executeAttack());
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault(); 
                if (this.isPlayerTurn) this.executeAttack();
            }
        });
        document.getElementById('modal-panel').addEventListener('click', (e) => {
            if(e.target.id === 'modal-panel' || e.target.textContent === 'Continue Battle') {
                this.hideModal();
            }
        });
    }

    // Monaco Editor initialization and configuration
    setupEditor() {
        const initialCode = `public class CombatSpell {
    public static void main(String[] args) {
        // Write your attack spell here!
        
    }
}`;
        // Monaco setup logic from original file
        require(['vs/editor/editor.main'], () => {
            // FIX: Define a basic theme to prevent 'Illegal theme base' error
            monaco.editor.defineTheme('rpgTheme', {
                base: 'vs-dark', // CRITICAL: Must define a base theme
                inherit: true,
                rules: [],
                colors: {
                    'editor.background': '#1e1e2d', // Deep blue/black
                    'editor.foreground': '#f8f8f2',
                    'editorCursor.foreground': '#bbbbbb',
                    'editorLineNumber.foreground': '#6D6D6D',
                    'editor.selectionBackground': '#43435c',
                }
            });

            this.gameState.editor = monaco.editor.create(document.getElementById('editor-container'), {
                value: initialCode,
                language: 'java',
                theme: 'rpgTheme', // Use the defined theme
                minimap: { enabled: false },
                scrollBeyondLastLine: false,
                automaticLayout: true,
                fontSize: 14,
            });
            
            this.gameState.editor.getModel().onDidChangeContent(() => this.updateRamCost());
            this.updateRamCost(); 
        });
    }

    // Start encounter logic (uses DataLoader)
    startEncounter() {
        // ... Load enemy logic ...
        this.enemy = DataLoader.getScaledEnemy('bugbear_conditional', this.gameState.player.level);
        if (!this.enemy) {
            this.ui.log('Error: Failed to load enemy data.', 'red');
            return;
        }
        
        this.ui.updateStats(this.gameState.player, this.enemy);
        this.ui.log(`A Level ${this.enemy.level} ${this.enemy.name} appears!`, 'blue');
    }
    
    // The core game flow methods (executeAttack, enemyTurn, playerRecharge, etc.)
    // ... all turn management and combat methods go here, relying on this.ui and this.analyzer ...
    
    updateRamCost() {
        if (!this.gameState.editor || !this.enemy) return; 
        const code = this.gameState.editor.getValue();
        const analysis = this.analyzer.analyze(code, this.enemy);
        this.ui.updateRamCostDisplay(analysis.finalRamCost, this.gameState.player.maxRam, analysis.hasSyntaxError);
    }
    
    // Simplified placeholder methods for structure
    executeAttack() {
        // ... (Attack logic from original file, including RAM checks and damage application)
        this.ui.log("Attack executed. (Full logic is in game.js)", 'yellow');
        this.isPlayerTurn = false;
        setTimeout(() => this.enemyTurn(), 2000); 
    }

    playerRecharge() {
        // ... (Recharge logic from original file)
        this.ui.log("Player recharges. (Full logic is in game.js)", 'green');
        this.isPlayerTurn = false;
        setTimeout(() => this.enemyTurn(), 1000); 
    }
    
    enemyTurn() {
        // ... (Enemy AI logic from original file)
        this.ui.log("Enemy turn complete. (Full logic is in game.js)", 'red');
        this.isPlayerTurn = true;
    }
    
    hideModal() {
        this.ui.hideModal();
    }
}